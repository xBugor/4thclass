package com.gamecodeschool.inheritanceexamples

import android.util.Log

class SpecialForces: Soldier(){
    fun SneakUpOnEnemy(){
        Log.i("Action","Sneaking up on enemy")
    }
}