package com.gamecodeschool.basicclasses

class AccessTester {




}