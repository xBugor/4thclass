package com.gamecodeschool.basicclasses

class Book(val title: String, var copiesSold: Int) {
    // Here we put our code as normal
    // But title and copiesSold are already
    // declared and initialized
}