package com.gamecodeschool.livedrawing

class ParticleSystem {
}