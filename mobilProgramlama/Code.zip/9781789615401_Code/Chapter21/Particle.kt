package com.gamecodeschool.livedrawing

class Particle {
}