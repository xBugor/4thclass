export const random = (min, max) => {
  return min + Math.floor((max - min) * Math.random());
};
