export const actionTypes = {
    INCREMENT: 1,
    DECREMENT: 2,
}