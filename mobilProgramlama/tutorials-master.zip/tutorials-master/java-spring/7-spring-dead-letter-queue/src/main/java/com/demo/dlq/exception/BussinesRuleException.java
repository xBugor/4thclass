package com.demo.dlq.exception;

public class BussinesRuleException extends Exception {

    public BussinesRuleException(String message) {
        super(message);
    }
}
