export const actionTypes = {
    INCREMENT: 1,
    DECREMENT: 2,
    LOGOUT: 3,
    AUTH_DATA: 4,
}